<?php
/**
 * �RTES�T�S K�LD�SE A MAPPA FELEL�S�NEK (PC VEZET�)
 */
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// PHPMailer bet�lt�se...
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

try {
    // Lek�rdezz�k az �j ig�nyt �s a hozz� tartoz� felel�s (vezet�) adatait
    // Felt�telezz�k a 'leader_notified' oszlop megl�t�t a Kerelem t�bl�kban
    $sql = "
        SELECT 'PM' as rendszer, k.kerelem_ID, ig.igenylo_nev as kerelmezo, 
               m.megosztas_neve, vez.igenylo_email as vezeto_email, vez.igenylo_nev as vezeto_nev
        FROM Kerelem k
        JOIN Igenylo ig ON k.igenylo_ID = ig.igenylo_ID
        JOIN Megosztasok m ON k.megosztas_ID = m.megosztas_ID
        JOIN Igenylo vez ON m.felelos_ID = vez.igenylo_ID
        WHERE k.leader_notified = 0
        
        UNION ALL
        
        SELECT 'DO' as rendszer, k.kerelem_ID, ig.igenylo_nev as kerelmezo, 
               m.megosztas_neve, vez.igenylo_email as vezeto_email, vez.igenylo_nev as vezeto_nev
        FROM Kerelem_DO k
        JOIN Igenylok_DO ig ON k.igenylo_ID = ig.igenylo_ID
        JOIN Megosztasok_DO m ON k.megosztas_ID = m.megosztas_ID
        JOIN Igenylok_DO vez ON m.felelos_ID = vez.igenylo_ID
        WHERE k.leader_notified = 0
        LIMIT 1";

    $stmt = $pdo->query($sql);
    $adat = $stmt->fetch();

    if ($adat) {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = '192.168.151.80';
        $mail->SMTPAuth = false;
        $mail->Port = 25;
        $mail->CharSet = 'UTF-8';

        $mail->setFrom('pmk.rma@phoenix-mecano.hu', 'FS Access Portal');

        // A c�mzett dinamikusan a t�bl�zatb�l vett felel�s lesz
        $mail->addAddress($adat['vezeto_email'], $adat['vezeto_nev']);

        $mail->isHTML(true);
        $mail->Subject = "J�v�hagy�sra v�r� hozz�f�r�s: " . $adat['megosztas_neve'];

        $mail->Body = "
            <h3>Tisztelt " . $adat['vezeto_nev'] . "!</h3>
            <p>�j hozz�f�r�si ig�ny �rkezett egy �n�z tartoz� mapp�hoz.</p>
            <table border='0' cellpadding='5'>
                <tr><td><strong>Ig�nyl�:</strong></td><td>" . $adat['kerelmezo'] . "</td></tr>
                <tr><td><strong>Mappa:</strong></td><td>" . $adat['megosztas_neve'] . "</td></tr>
                <tr><td><strong>Rendszer:</strong></td><td>" . $adat['rendszer'] . "</td></tr>
            </table>
            <p>K�rj�k, b�r�lja el az ig�nyt a port�lon.</p>
            <br>
            <p>�dv�zlettel,<br>IT Csapat</p>";

        if ($mail->send()) {
            // Jel�lj�k, hogy err�l a k�relemr�l m�r ment ki lev�l a vezet�nek
            $table = ($adat['rendszer'] === 'PM') ? 'Kerelem' : 'Kerelem_DO';
            $update = $pdo->prepare("UPDATE $table SET leader_notified = 1 WHERE kerelem_ID = ?");
            $update->execute([$adat['kerelem_ID']]);
        }
    }
} catch (Exception $e) {
    error_log("Hiba a vezet�i �rtes�t�sn�l: " . $e->getMessage());
}
?>